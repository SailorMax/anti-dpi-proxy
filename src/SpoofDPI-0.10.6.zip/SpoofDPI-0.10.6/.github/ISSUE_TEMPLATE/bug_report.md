---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

# Describe the bug


## Expected behavior


## Actual behavior


# How To Reproduce?


# Client information

**OS**:

**Version**:

# Additional context
