// Package dnsproxytest provides a set of test utilities for the dnsproxy
// module.
package dnsproxytest
