// Package handler provides some customizable DNS request handling logic used in
// the proxy.
package handler
