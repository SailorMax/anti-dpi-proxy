package main

import (
	"github.com/AdguardTeam/dnsproxy/internal/cmd"
)

func main() {
	cmd.Main()
}
