package proxy

import (
	"github.com/AdguardTeam/dnsproxy/internal/dnsmsg"
)

// MessageConstructor creates DNS messages.
type MessageConstructor = dnsmsg.MessageConstructor
